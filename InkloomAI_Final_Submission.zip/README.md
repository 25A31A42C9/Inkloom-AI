# Inkloom AI — Intelligent Brand Governance Platform

A browser-based MVP for explainable brand-content checks and human review.

## Run on Windows

1. Install Node.js 20 or newer.
2. Extract this ZIP.
3. Open the **InkloomAI** folder (the folder containing `package.json`) in VS Code.
4. Open Terminal and run:

```powershell
npm install
npm run dev
```

5. Open the localhost URL printed by Vite (normally http://localhost:5173/).

## Create a production build

```powershell
npm run build
```

The deployable static site is created in `dist/`.

## Included workflow

- Edit the brand identity and manage configurable guideline rules.
- Submit a draft and run deterministic, whole-word/phrase trigger matching against enabled rules.
- Review findings with severity, matched excerpt, rule ID, explanation, and suggested action.
- Apply suggestions, accept findings, or dismiss findings.
- View a heuristic compliance indicator and export a printable review report (choose **Save as PDF** in the browser print dialog).
- Save review sessions to local history.
- Persist rules, draft, brand name, and history in this browser using local storage.

## Important scope and limitations

This release is a self-contained MVP. The checker is a deterministic rule-matching engine; it is **not** a hosted LLM, external fact-checker, or legal-compliance service. It does not include a backend, cloud database, document ingestion, or multi-user authentication. Local storage is limited to the current browser/device. The score is a heuristic based on detected rule matches and is not a guarantee of compliance. Unsupported claims are surfaced for human verification; a human reviewer remains responsible for the final decision.

The Northstar brand, starter rules, and sample copy are illustrative demo data. Replace them with approved brand material before any real-world deployment.
